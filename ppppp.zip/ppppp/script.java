document.addEventListener('DOMContentLoaded', () => {
    let rows = 1;
    let cols = 1;
    
    // حاول تحميل البيانات المخزنة في الجلسة السابقة
    const savedMatrix = sessionStorage.getItem('matrix');
    if (savedMatrix) {
        const matrixData = JSON.parse(savedMatrix);
        rows = matrixData.rows;
        cols = matrixData.cols;
        createMatrixTable(rows, cols);
    } else {
        createMatrixTable(rows, cols);
    }

    // Generate the matrix when the button is clicked
    document.getElementById('generate-matrix').addEventListener('click', () => {
        rows = parseInt(document.getElementById('num-rows').value);
        cols = parseInt(document.getElementById('num-cols').value);
        createMatrixTable(rows, cols);
        // تخزين البيانات في sessionStorage
        sessionStorage.setItem('matrix', JSON.stringify({ rows, cols }));
    });

    // Generate the graph when the button is clicked
    document.getElementById("generate-graph").addEventListener("click", generateGraph);

    // Function to create the matrix table
    function createMatrixTable(rows, cols) {
        const tableBody = document.querySelector('#matrix-table tbody');
        tableBody.innerHTML = '';  // Clear the table

        for (let i = 0; i < rows; i++) {
            const row = document.createElement('tr');
            for (let j = 0; j < cols; j++) {
                const cell = document.createElement('td');
                const input = document.createElement('input');
                input.type = 'number';
                input.value = 0; // Default value
                cell.appendChild(input);
                row.appendChild(cell);
            }
            tableBody.appendChild(row);
        }
    }

    // Function to generate the graph
    function generateGraph() {
        const matrix = [];
        const inputs = document.querySelectorAll('#matrix-table input');
        
        let i = 0;
        for (let row = 0; row < rows; row++) {
            let rowArr = [];
            for (let col = 0; col < cols; col++) {
                rowArr.push(Number(inputs[i].value));
                i++;
            }
            matrix.push(rowArr);
        }

        // Create nodes (vertices)
        const nodes = [];
        // Create edges (connections)
        const edges = [];

        // Build nodes (vertices)
        for (let i = 0; i < matrix.length; i++) {
            nodes.push({ id: i + 1, label: `V${i + 1}` });

            // Build parallel edges
            for (let j = 0; j < matrix[i].length; j++) {
                let edgeCount = matrix[i][j]; // Number of parallel edges between node i and j
                if (edgeCount > 0) {
                    const edgeKey = `${i + 1}-${j + 1}`;

                    // Draw parallel edges with slight skew if there are more than 1 edge
                    for (let k = 0; k < edgeCount; k++) {
                        // If the edgeCount is 1, draw a normal edge (straight)
                        if (k === 0) {
                            edges.push({
                                id: `${edgeKey}-normal`,
                                from: i + 1,
                                to: j + 1,
                                color: getEdgeColor(k),
                                smooth: false, // Normal edge (straight)
                                width: 2,
                                arrowStrikethrough: false,
                                physics: true,
                                label: '',
                            });
                        } else {
                            // For parallel edges (k > 0), create a slight offset for better visibility (curved)
                            edges.push({
                                id: `${edgeKey}-parallel-${k}`,
                                from: i + 1,
                                to: j + 1,
                                color: getEdgeColor(k),
                                smooth: {
                                    type: 'curvedCW',  // Curved edges for parallel edges
                                    roundness: 0.5     // Adjust roundness for more curvature
                                },
                                width: 2 + k,  // Standard width for parallel edges
                                arrowStrikethrough: false,
                                physics: true,
                                label: '',
                                length: 150 + (k * 20), // Ensure separation between parallel edges
                            });
                        }
                    }
                }
            }
        }

        // Graph data configuration
        const container = document.getElementById('graph');
        const data = {
            nodes: new vis.DataSet(nodes),
            edges: new vis.DataSet(edges)
        };

        // Graph options
        const options = {
            physics: { enabled: true },
            nodes: {
                shape: 'circle',
                size: 15,
                color: document.getElementById("node-color").value
            },
            edges: {
                color: '#2d3e50',
                width: 2,
                smooth: { type: 'continuous', forceDirection: 'none' } // Default smooth for normal edges
            },
            layout: {
                randomSeed: 2,  // Add a random seed for better distribution
                improvedLayout: true,  // Improve layout for better distribution
                hierarchical: false,  // Disable hierarchical layout for free-form layout
            }
        };

        new vis.Network(container, data, options);
    }

    // Function to get a unique color for edges
    function getEdgeColor(index) {
        const colors = [
            '#FF5733', '#33FF57', '#3357FF', '#FF33A1', '#FFD700', '#8A2BE2', '#FF4500'
        ];
        return colors[index % colors.length];
    }

    // عند مغادرة الصفحة أو تحديثها، سيتم مسح البيانات المخزنة
    window.onbeforeunload = function () {
        sessionStorage.removeItem('matrix');
    };
});
